package v1alpha1

const (
	ClusterResourceQuotaCreatedby = "clusterresourcequota.quota.kubezoo.io/createdby"
)
