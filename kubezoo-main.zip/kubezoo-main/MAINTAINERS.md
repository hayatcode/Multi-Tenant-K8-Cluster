# The KubeZoo Maintainers

This file lists the maintainers of the KubeZoo project. The responsibilities of maintainers are listed in the [GOVERNANCE.md](GOVERNANCE.md) file.

## Project Maintainers
| Name | GitHub ID | Affiliation |
| ---- | --------- | ----------- |
| Jingsi Ren | [Silverglass](https://github.com/Silverglass) | ByteDance |
| Chen Xu | [xuchen-xiaoying](https://github.com/xuchen-xiaoying) | ByteDance |
| Deliang Fan | [DeliangFan](https://github.com/DeliangFan) | ByteDance |
| Jun Zhang | [zoumo](https://github.com/zoumo)| ByteDance |
| Charles Zheng | [charleszheng44](https://github.com/charleszheng44) | ByteDance |
| He Cao | [caohe](https://github.com/caohe) | ByteDance |
| Kwan Yin Chan | [SOF3](https://github.com/SOF3) | ByteDance |
